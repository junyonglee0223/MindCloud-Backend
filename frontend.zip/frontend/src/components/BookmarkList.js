import React, { useEffect, useState } from 'react';

const BookmarkList = () => {
  const [bookmarks, setBookmarks] = useState([]);

  useEffect(() => {
    // Chrome Storage에서 북마크 가져오기
    chrome.storage.sync.get(['bookmarks'], (result) => {
      setBookmarks(result.bookmarks || []);
    });
  }, []);

  return (
    <ul>
      {bookmarks.map((bookmark, index) => (
        <li key={index}>
          {bookmark.title} - <a href={bookmark.url} target="_blank" rel="noopener noreferrer">링크</a>
        </li>
      ))}
    </ul>
  );
};

export default BookmarkList;

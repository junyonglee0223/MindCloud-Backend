import React, { useState } from 'react';

const BookmarkForm = () => {
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // 북마크 저장 로직
    console.log('북마크 저장:', { url, title });
    
    // 북마크 저장 후 입력 필드 초기화
    setUrl('');
    setTitle('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="제목"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
      />
      <input
        type="url"
        placeholder="URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        required
      />
      <button type="submit">저장</button>
    </form>
  );
};

export default BookmarkForm;

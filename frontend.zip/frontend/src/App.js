import React from 'react';
import BookmarkForm from './components/BookmarkForm';
import BookmarkList from './components/BookmarkList';

const App = () => {
  return (
    <div>
      <h1>Bookmark Manager</h1>
      <BookmarkForm />
      <BookmarkList />
    </div>
  );
};

export default App;

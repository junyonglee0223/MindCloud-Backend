// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log('Bookmark Manager 확장 프로그램이 설치되었습니다.');
});

// 필요시 추가적인 이벤트 리스너 및 기능을 구현할 수 있습니다.
